package project1;

import java.util.ArrayList;
import java.util.Random;

public class Member extends User {
    public Member() {
    }

    public Member(String name, int balance) {
        super(name, balance);
    }

    public void receiveMoney(ArrayList<Integer> list) {
        int bal = list.remove(new Random().nextInt(list.size()));
        int money = super.getBalance();
        super.setBalance(money + bal);
    }
}

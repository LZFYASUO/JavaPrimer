package project1;

import java.util.ArrayList;
import java.util.Random;

public class GroupOwner extends User {
    public GroupOwner() {
    }

    public GroupOwner(String name, int balance) {
        super(name, balance);
    }

    public ArrayList<Integer> sendMoney(int totalMoney, int count, int sum) {
        ArrayList<Integer> list = new ArrayList<>();
        int money = super.getBalance();
        if (totalMoney > money) {
            System.out.println("余额不足！");
            return list;
        }
        int index = sum - 1;

        if (sum == 1) {
            System.out.println("没有群成员，发红包没有任何意义！");
        }
        if (count > index) {
            int avg = totalMoney / count;
            int mod = totalMoney % count;
            int remainder = 0;
            for (int i = 0; i < count - 1; i++) {
                list.add(avg);
            }
            list.add(avg + mod);
            for (int j = 0; j < count - index; j++) {
                remainder += list.remove(new Random().nextInt(count - j));
            }
            super.setBalance(money - totalMoney + remainder);
            return list;
        } else {
            int avg = totalMoney / count;
            int mod = totalMoney % count;
            super.setBalance(money - totalMoney);
            for (int i = 0; i < count - 1; i++) {
                list.add(avg);
            }
            list.add(avg + mod);
            return list;
        }
    }
}
package project1;

import java.util.ArrayList;
import java.util.Scanner;

public class RedPacket {
    public static void main(String[] args) {
        System.out.println("按平均分发红包！");
        System.out.println("请输入红包金额大小：");
        Scanner scan = new Scanner(System.in);
        int totalMoney = scan.nextInt();
        System.out.println("请输入红包个数：");
        Scanner scan1 = new Scanner(System.in);
        int count = scan.nextInt();
        System.out.println("请输入群成员人数：");
        Scanner scan2 = new Scanner(System.in);
        int sum = scan.nextInt();
        GroupOwner g = new GroupOwner("群主A", 80);
        Member m = new Member("群员B", 20);
        Member m1 = new Member("群员C", 10);
        Member m2 = new Member("群员D", 15);
        g.brief();
        m.brief();
        m1.brief();
        m2.brief();
        //ArrayList<Integer> a = g.sendMoney(70, 3, 4);
        ArrayList<Integer> a = g.sendMoney(totalMoney, count, sum);
        m.receiveMoney(a);
        m1.receiveMoney(a);
        m2.receiveMoney(a);
        g.brief();
        m.brief();
        m1.brief();
        m2.brief();


    }
}

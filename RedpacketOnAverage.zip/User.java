package project1;

public class User {
    private String name;
    private int balance;

    public User() {

    }
    public void brief(){
        System.out.println("身份是"+name+" 余额有"+balance);
    }
    public User(String name, int balance) {
        this.name = name;
        this.balance = balance;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public int getBalance() {
        return balance;
    }
}

package LuckyRedPacket;

import java.util.ArrayList;
import java.util.Random;

public class GroupOwner extends User {
    public GroupOwner(String name, int balance) {
        super(name, balance);
    }

    public GroupOwner() {
    }

    public ArrayList<Integer> sendMoney(int totalMoney, int count, int num) {
        ArrayList<Integer> list = new ArrayList<>();
        if (totalMoney > super.getBalance()) {
            System.out.println("余额不足！");
            return list;
        }
        if (num <= 1) {
            System.out.println("群成员只有群主，没有任何意义！");
        }
        int index = num - 1;
        if (count > index) {
            int leftMoney = totalMoney;
            int leftCount = count;
            int m = super.getBalance()-totalMoney;
            for (int i = 0; i < count - 1; i++) {
                int addMoney = 1 + new Random().nextInt(leftMoney / leftCount * 2);
                list.add(addMoney);
                leftMoney -= addMoney;
                leftCount--;
            }
            list.add(leftMoney);
            for (int j = 0; j < count - index; j++) {
                m += list.remove(new Random().nextInt(count - index - j));
            }
            super.setBalance(m);
            return list;
        } else {
            super.setBalance(super.getBalance() - totalMoney);
            int leftMoney = totalMoney;
            int leftCount = count;
            for (int i = 0; i < count - 1; i++) {
                int addMoney = 1 + new Random().nextInt(leftMoney / leftCount * 2);
                list.add(addMoney);
                leftMoney -= addMoney;
                leftCount--;
            }
            list.add(leftMoney);
            return list;
        }
    }
}

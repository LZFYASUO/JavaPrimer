package LuckyRedPacket;

import java.util.ArrayList;
import java.util.Random;

public class Member extends User {
    public Member() {
    }

    public Member(String name, int balance) {
        super(name, balance);
    }

    public void sendMoney(ArrayList<Integer> list) {
        int m = list.remove(new Random().nextInt(list.size()));
        super.setBalance(super.getBalance() + m);
    }
}

package LuckyRedPacket;

import java.util.ArrayList;
import java.util.Scanner;

public class RedPacket {
    public static void main(String[] args) {
        //钱是按分来计算单位
        System.out.println("这是拼手气红包！");
        System.out.println("请输入红包金额大小：");
        Scanner scan = new Scanner(System.in);
        int totalMoney = scan.nextInt();
        System.out.println("请输入红包个数：");
        Scanner scan1 = new Scanner(System.in);
        int count = scan.nextInt();
        System.out.println("请输入群成员人数：");
        Scanner scan2 = new Scanner(System.in);
        int sum = scan.nextInt();
        GroupOwner g = new GroupOwner("群主刘", 10000);
        Member m1 = new Member("群员A", 2000);
        Member m2 = new Member("群员B", 3000);
        Member m3 = new Member("群员C", 3000);
        g.brief();
        m1.brief();
        m2.brief();
        m3.brief();
        ArrayList<Integer> list = g.sendMoney(totalMoney, count, sum);
        m1.sendMoney(list);
        m2.sendMoney(list);
        m3.sendMoney(list);
        g.brief();
        m1.brief();
        m2.brief();
        m3.brief();
    }
}

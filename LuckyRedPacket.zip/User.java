package LuckyRedPacket;

public class User {
    private String name;
    private int balance;

    public User(String name, int balance) {
        this.name = name;
        this.balance = balance;
    }

    public void brief() {
        System.out.println("姓名" + name + " 余额有" + balance/100.0+"元");
    }

    public User() {
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public String getName() {
        return name;
    }

    public int getBalance() {
        return balance;
    }
}
